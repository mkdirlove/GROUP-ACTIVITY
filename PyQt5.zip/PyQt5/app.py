# -*- coding: utf-8 -*-

from PyQt5 import QtCore, QtGui, QtWidgets
from bubble import bubble
from quick import quick
from shell import shell
from heap import heap
from merge import merge
from insertion import insertion
from selection import selection

class mainWindow(object):
    def bubbleSort(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = bubble()
        self.ui.setupUi(self.window)
        self.window.show()

    def quickSort(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = quick()
        self.ui.setupUi(self.window)
        self.window.show()

    def shellSort(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = shell()
        self.ui.setupUi(self.window)
        self.window.show()

    def heapSort(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = heap()
        self.ui.setupUi(self.window)
        self.window.show()

    def mergeSort(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = merge()
        self.ui.setupUi(self.window)
        self.window.show()

    def insertionSort(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = insertion()
        self.ui.setupUi(self.window)
        self.window.show()

    def selectionSort(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = selection()
        self.ui.setupUi(self.window)
        self.window.show()
    
    def close(self):
        quit()

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(366, 418)
        self.pb3 = QtWidgets.QPushButton(Dialog)
        self.pb3.setGeometry(QtCore.QRect(10, 350, 141, 51))
        self.pb3.setObjectName("pb3")
        self.pb3.clicked.connect(self.heapSort)

        self.pb4 = QtWidgets.QPushButton(Dialog)
        self.pb4.setGeometry(QtCore.QRect(10, 280, 141, 51))
        self.pb4.setObjectName("pb4")
        self.pb4.clicked.connect(self.shellSort)

        self.pb1 = QtWidgets.QPushButton(Dialog)
        self.pb1.setGeometry(QtCore.QRect(10, 210, 141, 51))
        self.pb1.setObjectName("pb1")
        self.pb1.clicked.connect(self.quickSort)

        self.pb5 = QtWidgets.QPushButton(Dialog)
        self.pb5.setGeometry(QtCore.QRect(210, 140, 141, 51))
        self.pb5.setObjectName("pb5")
        self.pb5.clicked.connect(self.mergeSort)

        self.pb6 = QtWidgets.QPushButton(Dialog)
        self.pb6.setGeometry(QtCore.QRect(210, 210, 141, 51))
        self.pb6.setObjectName("pb6")
        self.pb6.clicked.connect(self.insertionSort)

        self.pb7 = QtWidgets.QPushButton(Dialog)
        self.pb7.setGeometry(QtCore.QRect(210, 280, 141, 51))
        self.pb7.setObjectName("pb7")
        self.pb7.clicked.connect(self.selectionSort)

        self.pb8 = QtWidgets.QPushButton(Dialog)
        self.pb8.setGeometry(QtCore.QRect(210, 350, 141, 51))
        self.pb8.setObjectName("pb8")
        self.pb8.clicked.connect(self.close) #######################################

        self.pb2 = QtWidgets.QPushButton(Dialog)
        self.pb2.setEnabled(True)
        self.pb2.setGeometry(QtCore.QRect(10, 140, 141, 51))
        self.pb2.setMouseTracking(False)
        self.pb2.setAcceptDrops(False)
        self.pb2.setObjectName("pb2")
        self.pb2.clicked.connect(self.bubbleSort)

        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(36, 19, 291, 71))
        font = QtGui.QFont()
        font.setPointSize(13)
        self.label.setFont(font)
        self.label.setObjectName("label")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.pb3.setText(_translate("Dialog", "HEAP SORT"))
        self.pb4.setText(_translate("Dialog", "SHELL SORT"))
        self.pb1.setText(_translate("Dialog", "QUICK SORT"))
        self.pb5.setText(_translate("Dialog", "MERGE SORT"))
        self.pb6.setText(_translate("Dialog", "INSERTION SORT"))
        self.pb7.setText(_translate("Dialog", "SELECTION SORT"))
        self.pb8.setText(_translate("Dialog", "CLOSE PROGRAM"))
        self.pb2.setText(_translate("Dialog", "BUBBLE SORT"))
        self.label.setText(_translate("Dialog", "     PYTHON  SORTING ALGORITHM"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = mainWindow()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
