# -*- coding: utf-8 -*-

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox

class bubble(object):
    my_list = 0
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 300)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(63, 70, 71, 19))
        self.label.setObjectName("label")
        self.tb1 = QtWidgets.QLineEdit(Dialog)
        self.tb1.setGeometry(QtCore.QRect(143, 70, 201, 27))
        self.tb1.setText("")
        self.tb1.setObjectName("tb1")
        self.tb1.setPlaceholderText("Enter element 1")


        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(70, 20, 261, 19))
        font = QtGui.QFont()
        font.setPointSize(15)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(63, 100, 71, 19))
        self.label_3.setObjectName("label_3")

        self.tb2 = QtWidgets.QLineEdit(Dialog)
        self.tb2.setGeometry(QtCore.QRect(143, 100, 201, 27))
        self.tb2.setText("")
        self.tb2.setObjectName("tb2")
        self.tb2.setPlaceholderText("Enter element 2")

        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(63, 130, 71, 19))
        self.label_4.setObjectName("label_4")

        self.tb3 = QtWidgets.QLineEdit(Dialog)
        self.tb3.setGeometry(QtCore.QRect(143, 130, 201, 27))
        self.tb3.setText("")
        self.tb3.setObjectName("tb3")
        self.tb3.setPlaceholderText("Enter element 3")

        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(63, 160, 71, 19))
        self.label_5.setObjectName("label_5")

        self.tb4 = QtWidgets.QLineEdit(Dialog)
        self.tb4.setGeometry(QtCore.QRect(143, 160, 201, 27))
        self.tb4.setText("")
        self.tb4.setObjectName("tb4")
        self.tb4.setPlaceholderText("Enter element 4")

        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(63, 190, 71, 19))
        self.label_6.setObjectName("label_6")

        self.tb5 = QtWidgets.QLineEdit(Dialog)
        self.tb5.setGeometry(QtCore.QRect(143, 190, 201, 27))
        self.tb5.setText("")
        self.tb5.setObjectName("tb5")
        self.tb5.setPlaceholderText("Enter element 5")

        self.pb1 = QtWidgets.QPushButton(Dialog)
        self.pb1.setGeometry(QtCore.QRect(60, 250, 281, 27))
        self.pb1.setObjectName("pb1")
        self.pb1.clicked.connect(self.calculate)
        

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Bubble Sort"))
        self.label.setText(_translate("Dialog", "Element 1:"))
        self.label_2.setText(_translate("Dialog", "BUBBLE SORT ALGORITHM"))
        self.label_3.setText(_translate("Dialog", "Element 2:"))
        self.label_4.setText(_translate("Dialog", "Element 3:"))
        self.label_5.setText(_translate("Dialog", "Element 4:"))
        self.label_6.setText(_translate("Dialog", "Element 5:"))
        self.pb1.setText(_translate("Dialog", "SORT THE LIST"))   
        
    def calculate(self):
        element1 = int(self.tb1.text())
        element2 = int(self.tb2.text())
        element3 = int(self.tb3.text())
        element4 = int(self.tb4.text())
        element5 = int(self.tb5.text())
        my_list = [element1, element2, element3, element4, element5]
        n = len(my_list) 
        for i in range(n-1): 
            for j in range(0, n-i-1): 
                if my_list[j] > my_list[j+1] : 
                    my_list[j], my_list[j+1] = my_list[j+1], my_list[j]
        
        msg = QMessageBox()
        msg.setWindowTitle("Sorted")
        msg.setText("Bubble Sort: " + str(my_list))
        x = msg.exec_()

        

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = bubble()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
